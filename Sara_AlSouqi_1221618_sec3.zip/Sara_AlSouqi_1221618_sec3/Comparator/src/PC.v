module Mux(A ,B ,sel ,out);
	input A ,B ,sel;
	output out;	
	reg notsel;
	wire andA ,andB;
	
	not #(4)(notsel , sel);
	and #(9)(andA , A ,sel);
	and #(9)(andB , B ,notsel);
	or #(9)(out ,andA , andB);
endmodule

 //done
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
module Comparator_1bit(A ,B ,EQ ,GT ,LT); 
	input A ,B;
	output EQ ,GT ,LT;
	wire notA ,notB;  
				
	not #(4)(notA ,A);
	not #(4)(notB ,B);
	and #(9)(GT ,A ,notB); 
	and #(9)(LT ,B ,notA);
	xnor #(10)(EQ ,A ,B);
endmodule


//done
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
module Twos_complement_for_singed ( A ,twos_complement);
    input [5:0] A;  				 // 6-bit input
    output [5:0] twos_complement;  // 6-bit sum output
	
    wire [5:0] Carry;  				// Internal carry signals
	reg [5:0] ones_complement;
	
	genvar i;
	generate 
	for(i = 0 ; i < 6 ; i=i+1)
		begin
			not #(4)(ones_complement[i] ,A[i]);	   //ones complement
		end
	endgenerate
	
    // LSB Half Adder (Add A[0] + 1)
    xor (twos_complement[0], ones_complement[0], 1'b1);        // Sum for LSB
    and (Carry[0], ones_complement[0], 1'b1);                  // Carry for LSB
  
		
    // Full Adder for remaining bits 
    generate
	for (i = 1; i < 6; i = i + 1) 
		begin : full_adder
            xor #(13)(twos_complement[i], ones_complement[i], Carry[i-1]);        // Sum = A XOR B XOR CarryIn
            and #(9) (Carry[i], ones_complement[i], Carry[i-1]);    				 // A AND CarryIn
        end
    endgenerate

endmodule

//done
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
module Comparator_unsigned(A ,B ,EQ ,GT ,LT);
	
	input[5:0]A ,B;
	output EQ ,GT ,LT;
	reg [5:0]EQArray , GTArray ,LTArray ;
	reg INV ,notA ,notB;
	reg G4E5 ,G3E5E4 ,G2E5E4E3 ,G1E5E4E3E2 ,G0E5E4E3E2E1 ,L4E5 ,L3E5E4 ,L2E5E4E3 ,L1E5E4E3E2 ,L0E5E4E3E2E1;
	genvar i;  
			generate
			for(i = 0 ; i < 6 ; i=i+1)
				begin 
					// comparator for one bit
					Comparator_1bit c(A[i] ,B[i] ,EQArray[i] ,GTArray[i] ,LTArray[i]);  	
				end
			endgenerate
			
			//  A = B     --->  E = E5.E4.E3.E2.E1.E0
			and #(9)(EQ ,EQArray[0] ,EQArray[1] ,EQArray[2] ,EQArray[3] ,EQArray[4] ,EQArray[5]);	
			
			  // A > B	  ---> GT = G5 + G4.E5 + G3.E5.E4 + G2.E5.E4.E3 + G1.E5.E4.E3.E2 + G0.E5.E4.E3.E2.E1
			and #(9)(G4E5 ,GTArray[4] ,EQArray[5]);
			and #(9)(G3E5E4 ,GTArray[3] ,EQArray[5] ,EQArray[4]);
			and #(9)(G2E5E4E3,GTArray[2] ,EQArray[5] ,EQArray[4] ,EQArray[3]);
			and #(9)(G1E5E4E3E2,GTArray[1] ,EQArray[5] ,EQArray[4] ,EQArray[3] ,EQArray[2]);
			and #(9)(G0E5E4E3E2E1,GTArray[0] ,EQArray[5] ,EQArray[4] ,EQArray[3] ,EQArray[2] ,EQArray[1]);
			or #(9)(GT ,GTArray[5] ,G4E5 ,G3E5E4 ,G2E5E4E3 ,G1E5E4E3E2 ,G0E5E4E3E2E1); 
			
			// A < B	  ---> LT = L5 + L4.E5 + L3.E5.E4 + L2.E5.E4.E3 + L1.E5.E4.E3.E2 + L0.E5.E4.E3.E2.E1
			and #(9)(L4E5 ,LTArray[4] ,EQArray[5]);
			and #(9)(L3E5E4 ,LTArray[3] ,EQArray[5] ,EQArray[4]);
			and #(9)(L2E5E4E3,LTArray[2] ,EQArray[5] ,EQArray[4] ,EQArray[3]);
			and #(9)(L1E5E4E3E2,LTArray[1] ,EQArray[5] ,EQArray[4] ,EQArray[3] ,EQArray[2]);
			and #(9)(L0E5E4E3E2E1,LTArray[0] ,EQArray[5] ,EQArray[4] ,EQArray[3] ,EQArray[2] ,EQArray[1]);
			or #(9)(LT ,LTArray[5] ,L4E5 ,L3E5E4 ,L2E5E4E3 ,L1E5E4E3E2 ,L0E5E4E3E2E1);
			
endmodule
 //done
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
module Comparator_signed(A ,B ,EQ ,GT ,LT);	
	input[5:0]A ,B;			// input
	output EQ ,GT ,LT;		// output
	wire [5:0]twos_complement_A ,twos_complement_B;
	
	Twos_complement_for_singed T1( A ,twos_complement_A);	//twos complement for input A
	Twos_complement_for_singed T2( B ,twos_complement_B);  //twos complement for input B
	Comparator_unsigned C1(twos_complement_A ,twos_complement_B ,EQ ,GT ,LT ); //Comparator between A and B after converted 
endmodule
//done
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

module General_Comparator(A ,B ,Sel ,EQ_general ,LT_general ,GT_general); 
	input [5:0]A ,B;
	input Sel;	 
	output EQ_general ,LT_general ,GT_general;
	wire EQ_signed ,EQ_unsigned ,GT_signed ,GT_unsigned ,LT_signed ,LT_unsigned;
	
	 Comparator_unsigned C1(A ,B ,EQ_unsigned ,GT_unsigned ,LT_unsigned); //unsigned comparator
	 Comparator_signed C2(A ,B ,EQ_signed ,GT_signed ,LT_signed); //signed comparator
	 // mux to select output based on selection
	 Mux M1(EQ_signed ,EQ_unsigned ,Sel ,EQ_general);	 
	 Mux M2(GT_signed ,GT_unsigned ,Sel ,GT_general);
	 Mux M3(LT_signed ,LT_unsigned ,Sel ,LT_general);	 
endmodule
//done
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
module FlipFlop_13bit (A ,B ,Sel ,CLK ,Q ,Qbar);
	
    input [5:0] A ,B;              
    input Sel ,CLK;                
    output [12:0] Q ,Qbar;

    wire [12:0] D;        // Data input to the flip-flop

    // Concatenate A, B, and Selection into D
    assign D = {A, B, Sel};

    // Generate D Flip-Flops for each bit of the 13-bit register
    genvar i;
    generate
	for (i = 0; i < 13; i = i + 1) 
		begin : flip_flop  
            DFlipFlop dff (D[i], CLK, Q[i] ,Qbar[i]);
        end
    endgenerate
	
endmodule

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
module FlipFlop_3bit (GT ,EQ ,LT ,CLK ,Q ,Qbar);
	
    input GT ,EQ ,LT ,CLK;                              
    output [2:0] Q ,Qbar;

    wire [2:0] D;        // Data input to the flip-flop

    // Concatenate A, B, and Selection into D
    assign D = {GT ,EQ ,LT};

    // Generate D Flip-Flops for each bit of the 13-bit register
    genvar i;
    generate
	for (i = 0; i < 3; i = i + 1) 
		begin : flip_flop  
            DFlipFlop dff (D[i], CLK, Q[i] ,Qbar[i]);
        end
    endgenerate
	
endmodule  
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Module for a single-bit D Flip-Flop
module DFlipFlop (D ,CLK ,Q ,Qbar);
    input D ,CLK;     
    output Q ,Qbar;	
    wire nD ,w1 ,w2;
							   // structurlly D_FF
    not #(4)(nD, D);               	 
	nand #(6)(w1 ,D ,CLK);
	nand #(6)(w2 ,nD ,CLK);
	nand #(6)(Q , Qbar , w1);
	nand #(6)(Qbar , Q , w2);
endmodule
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
module system (A ,B ,Sel ,CLK ,EQ ,GT ,LT);
	input [5:0]A ,B;
	input Sel ,CLK;
	output EQ ,GT ,LT;
	
	wire [5:0] A_reg, B_reg;
	wire Sel_reg;

	wire [12:0]QFF1 ,QbarFF1;
	wire [2:0]QFF2 ,QbarFF2;
	wire EQ_general ,LT_general ,GT_general;
	
	FlipFlop_13bit F1(A ,B ,Sel ,CLK ,QFF1 ,QbarFF1);	// first register to enter the input at CLK
	assign {A_reg, B_reg, Sel_reg} = QFF1; 				// after enter 13bit input "QFF1" --> (6bit input A , 6bit input B , 1bit selection) will store in register input 
	General_Comparator GC(A_reg, B_reg, Sel_reg ,EQ_general ,LT_general ,GT_general); // compare between the inputs based on selection
	FlipFlop_3bit F2(GT_general ,EQ_general ,LT_general ,CLK ,QFF2 ,QbarFF2);	   	// store the result on second register 
	assign {GT , EQ , LT} = QFF2;											 		// the output "QFF2" --> will divide the result on the output 
									// NOTE: will concate the input and output to be able to enter to D_FF(because its for 1bit)
endmodule  


module behavioral_System(
    input [5:0] A, B, // 6-bit inputs
    input Sel, CLK,   // Selection and clock signals
    output reg EQ,    // Equality output
    output reg GT,    // Greater than output
    output reg LT     // Less than output
);

    always @(*) begin
        if (Sel == 0) begin
            // Unsigned comparison
            if (A > B) begin
                GT <= 1'b1;
                EQ <= 1'b0;
                LT <= 1'b0;
            end else if (A < B) begin
                GT <= 1'b0;
                EQ <= 1'b0;
                LT <= 1'b1;
            end else begin
                GT <= 1'b0;
                EQ <= 1'b1;
                LT <= 1'b0;
            end
        end else if(Sel == 1) begin
            // Signed comparison
            if (A[5] == B[5]) begin
                // Same MSP 
                if (A > B) begin
                    GT <= 1'b1;
                    EQ <= 1'b0;
                    LT <= 1'b0;
                end else if (A < B) begin
                    GT <= 1'b0;
                    EQ <= 1'b0;
                    LT <= 1'b1;
                end else begin
                    GT <= 1'b0;
                    EQ <= 1'b1;
                    LT <= 1'b0;
                end
            end else if (A[5] == 1 && B[5] == 0) begin
                // A is negative, B is positive
                GT <= 1'b0;
                EQ <= 1'b0;
                LT <= 1'b1;
            end else begin
                // A is positive, B is negative
                GT <= 1'b1;
                EQ <= 1'b0;
                LT <= 1'b0;
            end
        end
    end
endmodule

		
module TestBench_System();
    reg [5:0] A, B;    // 6-bit inputs
    reg Sel, CLK;      // Selection and clock signals
    wire GT0, EQ0, LT0 ,GT1, EQ1, LT1;   // Outputs

    
    system sys(A, B, Sel, CLK, EQ0, GT0, LT0);	 // Instantiate the system structural module
   	behavioral_System Bsys(A ,B ,Sel ,CLK ,EQ1 ,GT1 ,LT1);	  // Instantiate the system behavioral module
	   
    initial begin  
		{A ,B} = 0;
		Sel = 1'b0;
        CLK = 1'b0;
        
        repeat (8191) begin // Limited to 64 iterations	 
			#70ns CLK = ~CLK;
			//will test random value 
			 A = $random % 64; // Random 6-bit value for A
             B = $random % 64; // Random 6-bit value for B
			 Sel = ~Sel;	
			#13ns;
			 $write("STRUCTURAL::: time: %0d ,CLK: %b ,A: %b ,B: %b ,Sel: %b ,EQ: %b , GT: %b ,LT: %b\nBEHAVIORAL::: time: %0d ,CLK: %b ,A: %b ,B: %b ,Sel: %b ,EQ: %b , GT: %b ,LT: %b\n ",$time ,CLK ,A,B,Sel,EQ0,GT0,LT0 ,$time,CLK ,A,B,Sel,EQ1,GT1,LT1);
				if(EQ0 == EQ1 && GT0 == GT1 && LT0 == LT1)
					$display("PASS");
				else
					$display("FAIL");
		
            CLK = ~CLK;
        end
    end
endmodule


